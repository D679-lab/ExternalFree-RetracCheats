README
This is the downloadable version of the external retrac cheat
still no viruses, and no flags
you can also read the code if you want. 
If you have any trouble go to the discord and find the help section or the command prompt help section.
Have fun.