import cv2
import numpy as np
from mss import mss
from ultralytics import YOLO
import pygame
import win32gui
import win32con
import win32api
import math
import time
import tkinter as tk
from threading import Thread

# --- Configurations ---
MODEL_NAME = "yolov8n.pt"
CONFIDENCE_THRESHOLD = 0.30
TARGET_FPS = 60  # Maximum overlay refresh rate

# Available colors mapping (Name: RGB Tuple)
COLORS = {
    "Red": (255, 0, 0),
    "Green": (0, 255, 0),
    "Blue": (0, 0, 255),
    "Yellow": (255, 255, 0),
    "White": (255, 255, 255)
}
COLOR_LIST = list(COLORS.keys())

class MenuSettings:
    def __init__(self):
        self.menu_visible = True
        self.esp_enabled = True
        self.aim_enabled = True
        self.fov_enabled = True
        self.fov_radius = 150
        self.aim_key = 0x02  # Right Mouse Button
        
        # Color settings (Stored as RGB tuples)
        self.box_color = COLORS["Red"]
        self.fov_color = COLORS["Green"]

settings = MenuSettings()

def run_menu():
    root = tk.Tk()
    root.title("Overlay Controller")
    root.geometry("280x320")
    root.attributes("-topmost", True)
    root.configure(bg="#222222")
    
    def on_closing():
        root.withdraw()
        settings.menu_visible = False

    root.protocol("WM_DELETE_WINDOW", on_closing)

    tk_esp = tk.BooleanVar(value=settings.esp_enabled)
    tk_aim = tk.BooleanVar(value=settings.aim_enabled)
    tk_fov = tk.BooleanVar(value=settings.fov_enabled)

    def update_settings():
        settings.esp_enabled = tk_esp.get()
        settings.aim_enabled = tk_aim.get()
        settings.fov_enabled = tk_fov.get()

    # Track current indexes for cycling colors
    box_color_idx = [COLOR_LIST.index("Red")]
    fov_color_idx = [COLOR_LIST.index("Green")]

    def cycle_box_color():
        box_color_idx[0] = (box_color_idx[0] + 1) % len(COLOR_LIST)
        color_name = COLOR_LIST[box_color_idx[0]]
        settings.box_color = COLORS[color_name]
        btn_box_color.config(text=f"Box Color: {color_name}")

    def cycle_fov_color():
        fov_color_idx[0] = (fov_color_idx[0] + 1) % len(COLOR_LIST)
        color_name = COLOR_LIST[fov_color_idx[0]]
        settings.fov_color = COLORS[color_name]
        btn_fov_color.config(text=f"FOV Color: {color_name}")

    tk.Label(root, text="FEATURES MENU", font=("Arial", 12, "bold"), fg="white", bg="#222222").pack(pady=10)
    
    tk.Checkbutton(root, text="Enable ESP Boxes", variable=tk_esp, command=update_settings, fg="white", bg="#222222", selectcolor="#333333").pack(anchor="w", padx=30, pady=3)
    tk.Checkbutton(root, text="Enable Aim Assist", variable=tk_aim, command=update_settings, fg="white", bg="#222222", selectcolor="#333333").pack(anchor="w", padx=30, pady=3)
    tk.Checkbutton(root, text="Show FOV Ring", variable=tk_fov, command=update_settings, fg="white", bg="#222222", selectcolor="#333333").pack(anchor="w", padx=30, pady=3)
    
    # Color customization buttons
    btn_box_color = tk.Button(root, text="Box Color: Red", command=cycle_box_color, bg="#333333", fg="white", width=18)
    btn_box_color.pack(pady=5)

    btn_fov_color = tk.Button(root, text="FOV Color: Green", command=cycle_fov_color, bg="#333333", fg="white", width=18)
    btn_fov_color.pack(pady=5)

    tk.Label(root, text="Press [INSERT] to Hide/Show Menu", font=("Arial", 8, "italic"), fg="#aaaaaa", bg="#222222").pack(pady=15)

    while True:
        try:
            if settings.menu_visible:
                root.deiconify()
                root.update()
            else:
                root.withdraw()
                root.update_idletasks()
            time.sleep(0.05)
        except tk.TclError:
            break

def mouse_move_relative(dx, dy):
    win32api.mouse_event(win32con.MOUSEEVENTF_MOVE, int(dx), int(dy), 0, 0)

def main():
    menu_thread = Thread(target=run_menu, daemon=True)
    menu_thread.start()

    pygame.init()
    
    with mss() as sct:
        monitor = sct.monitors[1]
        screen_w, screen_h = monitor["width"], monitor["height"]
        screen_center_x, screen_center_y = screen_w // 2, screen_h // 2
        
        # Performance adjustment: Dynamic tight-bound capture region
        crop_size = settings.fov_radius * 2 + 40 
        roi = {
            "top": max(0, screen_center_y - (crop_size // 2)),
            "left": max(0, screen_center_x - (crop_size // 2)),
            "width": crop_size,
            "height": crop_size
        }

        screen = pygame.display.set_mode((screen_w, screen_h), pygame.NOFRAME | pygame.SRCALPHA | pygame.DOUBLEBUF)
        hwnd = pygame.display.get_wm_info()['window']
        
        styles = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, 
                               styles | win32con.WS_EX_LAYERED | win32con.WS_EX_TRANSPARENT | win32con.WS_EX_TOPMOST)
        
        TRANSPARENT_COLOR = (0, 0, 0)
        COLOR_KEY = win32api.RGB(0, 0, 0)
        win32gui.SetLayeredWindowAttributes(hwnd, COLOR_KEY, 0, win32con.LWA_COLORKEY)

        win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, screen_w, screen_h, 
                              win32con.SWP_NOACTIVATE | win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)

        model = YOLO(MODEL_NAME)
        clock = pygame.time.Clock()
        
        insert_key_pressed = False
        running = True
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            if win32api.GetAsyncKeyState(win32con.VK_INSERT) & 0x8000:
                if not insert_key_pressed:
                    settings.menu_visible = not settings.menu_visible
                    insert_key_pressed = True
            else:
                insert_key_pressed = False

            screen.fill(TRANSPARENT_COLOR)

            if settings.fov_enabled:
                pygame.draw.circle(screen, settings.fov_color, (screen_center_x, screen_center_y), settings.fov_radius, 1)

            # High-speed screen grab
            screen_shot = sct.grab(roi)
            frame_bgr = cv2.cvtColor(np.array(screen_shot), cv2.COLOR_BGRA2BGR)
            
            # Optimized: Changed imgsz to 160 for lower latency & immediate box tracking on moving targets
            results = model.predict(frame_bgr, classes=[0], conf=CONFIDENCE_THRESHOLD, imgsz=160, verbose=False)

            closest_target = None
            min_distance = float('inf')

            for result in results:
                boxes = result.boxes.xyxy.cpu().numpy()
                for box in boxes:
                    rx1, ry1, rx2, ry2 = map(int, box[:4])
                    x1 = rx1 + roi["left"]
                    y1 = ry1 + roi["top"]
                    box_w = rx2 - rx1
                    box_h = ry2 - ry1

                    target_center_x = x1 + (box_w // 2)
                    target_center_y = y1 + (box_h // 2)
                    distance = math.sqrt((target_center_x - screen_center_x)**2 + (target_center_y - screen_center_y)**2)

                    if settings.esp_enabled:
                        pygame.draw.rect(screen, settings.box_color, (x1, y1, box_w, box_h), 2)

                    if distance <= settings.fov_radius and distance < min_distance:
                        min_distance = distance
                        closest_target = (target_center_x, target_center_y)

            if settings.aim_enabled and (win32api.GetAsyncKeyState(settings.aim_key) & 0x8000):
                if closest_target is not None:
                    diff_x = closest_target[0] - screen_center_x
                    diff_y = closest_target[1] - screen_center_y
                    mouse_move_relative(diff_x, diff_y)

            pygame.display.flip()
            clock.tick(TARGET_FPS)

    pygame.quit()

if __name__ == "__main__":
    main()