import cv2
import numpy as np
from mss import mss
from ultralytics import YOLO
import pygame
import win32gui
import win32con
import win32api
import math
import time
import tkinter as tk
from tkinter import ttk
from threading import Thread, Lock
import torch

# --- Configurations ---
MODEL_NAME = "yolov8n.pt"
CONFIDENCE_THRESHOLD = 0.15
TARGET_FPS = 120

class ExtremeSettings:
    def __init__(self):
        self.lock = Lock()
        # Toggle Features
        self.aimbot_enabled = True
        self.esp_enabled = True
        self.fov_enabled = True
        self.head_only_mode = True
        self.instant_lock = True
        self.snap_aim = False
        self.draw_skeleton = False
        
        # Aimbot Settings
        self.aim_key = 0x02  # Right Mouse Button
        self.aim_smoothing = 0.1  # VERY LOW for snappy aim
        self.snap_speed = 50  # Instant snap speed
        self.fov_radius = 500  # HUGE FOV
        self.head_prediction = 2.0  # Lead targets
        
        # Visual Settings
        self.esp_distance_lines = True
        self.crosshair_enabled = True
        self.head_box_color = (0, 255, 255)
        self.body_box_color = (0, 255, 0)
        self.esp_text_enabled = True
        self.rainbow_mode = False
        
        # Trigger Settings
        self.trigger_bot_enabled = False
        self.trigger_delay = 0.05
        self.auto_fire = False
        self.reload_time = 3.0
        
        self.menu_visible = True

    def get_setting(self, attr):
        with self.lock:
            return getattr(self, attr)

    def set_setting(self, attr, value):
        with self.lock:
            setattr(self, attr, value)

settings = ExtremeSettings()

class AdvancedMenu:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("EXTREME AIMBOT v1.0")
        self.root.geometry("500x800")
        self.root.attributes("-topmost", True)
        self.root.configure(bg="#1a1a1a")
        self.color_counter = 0
        
        self.setup_ui()
        
    def setup_ui(self):
        # Header
        header = tk.Label(self.root, text="⚡ EXTREME AIMBOT ⚡", 
                         font=("Arial", 14, "bold"), fg="#FF0000", bg="#1a1a1a")
        header.pack(pady=15)
        
        # Notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)
        
        # AIMBOT TAB
        aimbot_frame = tk.Frame(self.notebook, bg="#2a2a2a")
        self.notebook.add(aimbot_frame, text="AIMBOT")
        self.create_aimbot_tab(aimbot_frame)
        
        # ESP TAB
        esp_frame = tk.Frame(self.notebook, bg="#2a2a2a")
        self.notebook.add(esp_frame, text="ESP")
        self.create_esp_tab(esp_frame)
        
        # VISUALS TAB
        visuals_frame = tk.Frame(self.notebook, bg="#2a2a2a")
        self.notebook.add(visuals_frame, text="VISUALS")
        self.create_visuals_tab(visuals_frame)
        
        # TRIGGER TAB
        trigger_frame = tk.Frame(self.notebook, bg="#2a2a2a")
        self.notebook.add(trigger_frame, text="TRIGGER")
        self.create_trigger_tab(trigger_frame)
        
        # Footer
        footer = tk.Label(self.root, text="[INSERT] Hide Menu | [DELETE] Exit | Status: RUNNING", 
                         font=("Arial", 9), fg="#00FF00", bg="#1a1a1a")
        footer.pack(pady=10)
    
    def create_aimbot_tab(self, parent):
        tk.Label(parent, text="AIMBOT SETTINGS", font=("Arial", 11, "bold"), 
                fg="#FF0000", bg="#2a2a2a").pack(pady=10)
        
        # Enable Aimbot
        self.aimbot_var = tk.BooleanVar(value=settings.get_setting('aimbot_enabled'))
        tk.Checkbutton(parent, text="🔫 Enable Aimbot", variable=self.aimbot_var, 
                      command=self.update_aimbot, fg="#00FF00", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        # Head Only Mode
        self.head_only_var = tk.BooleanVar(value=settings.get_setting('head_only_mode'))
        tk.Checkbutton(parent, text="💀 Head Only Mode (CRAZY)", variable=self.head_only_var, 
                      command=self.update_head_only, fg="#00FFFF", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        # Instant Lock
        self.instant_lock_var = tk.BooleanVar(value=settings.get_setting('instant_lock'))
        tk.Checkbutton(parent, text="⚡ Instant Lock (BLATANT)", variable=self.instant_lock_var, 
                      command=self.update_instant_lock, fg="#FF00FF", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        # Snap Aim
        self.snap_var = tk.BooleanVar(value=settings.get_setting('snap_aim'))
        tk.Checkbutton(parent, text="🎯 Snap Aim", variable=self.snap_var, 
                      command=self.update_snap, fg="#FFFF00", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        # FOV Slider
        tk.Label(parent, text="FOV Radius (px):", fg="white", bg="#2a2a2a").pack(anchor="w", padx=20, pady=(10, 0))
        fov_slider = tk.Scale(parent, from_=100, to=800, orient=tk.HORIZONTAL, 
                            command=self.update_fov, bg="#333333", fg="#00FF00", 
                            highlightthickness=0)
        fov_slider.set(settings.get_setting('fov_radius'))
        fov_slider.pack(padx=20, fill="x", pady=(0, 10))
        
        # Aim Smoothing
        tk.Label(parent, text="Aim Smoothing (Snap Speed):", fg="white", bg="#2a2a2a").pack(anchor="w", padx=20, pady=(10, 0))
        smooth_slider = tk.Scale(parent, from_=0.01, to=5, orient=tk.HORIZONTAL, 
                               command=self.update_smoothing, bg="#333333", fg="#FF0000", 
                               highlightthickness=0, resolution=0.1)
        smooth_slider.set(settings.get_setting('aim_smoothing'))
        smooth_slider.pack(padx=20, fill="x", pady=(0, 10))
        
        # Head Prediction
        tk.Label(parent, text="Head Prediction (Lead):", fg="white", bg="#2a2a2a").pack(anchor="w", padx=20, pady=(10, 0))
        pred_slider = tk.Scale(parent, from_=0, to=10, orient=tk.HORIZONTAL, 
                             command=self.update_prediction, bg="#333333", fg="#00FFFF", 
                             highlightthickness=0, resolution=0.5)
        pred_slider.set(settings.get_setting('head_prediction'))
        pred_slider.pack(padx=20, fill="x", pady=(0, 10))
    
    def create_esp_tab(self, parent):
        tk.Label(parent, text="ESP SETTINGS", font=("Arial", 11, "bold"), 
                fg="#00FF00", bg="#2a2a2a").pack(pady=10)
        
        self.esp_var = tk.BooleanVar(value=settings.get_setting('esp_enabled'))
        tk.Checkbutton(parent, text="👁️ Enable ESP", variable=self.esp_var, 
                      command=self.update_esp, fg="#00FF00", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        self.distance_var = tk.BooleanVar(value=settings.get_setting('esp_distance_lines'))
        tk.Checkbutton(parent, text="📏 Distance Lines", variable=self.distance_var, 
                      command=self.update_distance, fg="#0088FF", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        self.text_var = tk.BooleanVar(value=settings.get_setting('esp_text_enabled'))
        tk.Checkbutton(parent, text="📝 ESP Text", variable=self.text_var, 
                      command=self.update_esp_text, fg="#FFFF00", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        self.skeleton_var = tk.BooleanVar(value=settings.get_setting('draw_skeleton'))
        tk.Checkbutton(parent, text="🦴 Skeleton Lines", variable=self.skeleton_var, 
                      command=self.update_skeleton, fg="#FF00FF", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        self.rainbow_var = tk.BooleanVar(value=settings.get_setting('rainbow_mode'))
        tk.Checkbutton(parent, text="🌈 Rainbow Mode", variable=self.rainbow_var, 
                      command=self.update_rainbow, fg="#FF0088", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
    
    def create_visuals_tab(self, parent):
        tk.Label(parent, text="VISUAL SETTINGS", font=("Arial", 11, "bold"), 
                fg="#FF00FF", bg="#2a2a2a").pack(pady=10)
        
        self.fov_var = tk.BooleanVar(value=settings.get_setting('fov_enabled'))
        tk.Checkbutton(parent, text="⭕ Show FOV Circle", variable=self.fov_var, 
                      command=self.update_fov_vis, fg="#00FF00", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        self.crosshair_var = tk.BooleanVar(value=settings.get_setting('crosshair_enabled'))
        tk.Checkbutton(parent, text="✖️ Crosshair", variable=self.crosshair_var, 
                      command=self.update_crosshair, fg="#FF00FF", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        tk.Label(parent, text="Status: ACTIVE ✓", font=("Arial", 12, "bold"), 
                fg="#00FF00", bg="#2a2a2a").pack(pady=20)
    
    def create_trigger_tab(self, parent):
        tk.Label(parent, text="TRIGGER BOT", font=("Arial", 11, "bold"), 
                fg="#FF0000", bg="#2a2a2a").pack(pady=10)
        
        self.trigger_var = tk.BooleanVar(value=settings.get_setting('trigger_bot_enabled'))
        tk.Checkbutton(parent, text="🔔 Enable Trigger Bot", variable=self.trigger_var, 
                      command=self.update_trigger, fg="#FF0000", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        self.auto_fire_var = tk.BooleanVar(value=settings.get_setting('auto_fire'))
        tk.Checkbutton(parent, text="🔫 Auto Fire", variable=self.auto_fire_var, 
                      command=self.update_autofire, fg="#FF6600", bg="#2a2a2a", 
                      selectcolor="#333333", font=("Arial", 10)).pack(anchor="w", padx=20, pady=5)
        
        tk.Label(parent, text="Trigger Delay (ms):", fg="white", bg="#2a2a2a").pack(anchor="w", padx=20, pady=(10, 0))
        delay_slider = tk.Scale(parent, from_=10, to=500, orient=tk.HORIZONTAL, 
                              command=self.update_delay, bg="#333333", fg="#FF0000", 
                              highlightthickness=0)
        delay_slider.set(settings.get_setting('trigger_delay') * 1000)
        delay_slider.pack(padx=20, fill="x", pady=(0, 10))
    
    def update_aimbot(self):
        settings.set_setting('aimbot_enabled', self.aimbot_var.get())
    
    def update_head_only(self):
        settings.set_setting('head_only_mode', self.head_only_var.get())
    
    def update_instant_lock(self):
        settings.set_setting('instant_lock', self.instant_lock_var.get())
    
    def update_snap(self):
        settings.set_setting('snap_aim', self.snap_var.get())
    
    def update_esp(self):
        settings.set_setting('esp_enabled', self.esp_var.get())
    
    def update_distance(self):
        settings.set_setting('esp_distance_lines', self.distance_var.get())
    
    def update_esp_text(self):
        settings.set_setting('esp_text_enabled', self.esp_text_var.get())
    
    def update_skeleton(self):
        settings.set_setting('draw_skeleton', self.skeleton_var.get())
    
    def update_rainbow(self):
        settings.set_setting('rainbow_mode', self.rainbow_var.get())
    
    def update_fov_vis(self):
        settings.set_setting('fov_enabled', self.fov_var.get())
    
    def update_crosshair(self):
        settings.set_setting('crosshair_enabled', self.crosshair_var.get())
    
    def update_trigger(self):
        settings.set_setting('trigger_bot_enabled', self.trigger_var.get())
    
    def update_autofire(self):
        settings.set_setting('auto_fire', self.auto_fire_var.get())
    
    def update_fov(self, val):
        settings.set_setting('fov_radius', int(float(val)))
    
    def update_smoothing(self, val):
        settings.set_setting('aim_smoothing', float(val))
    
    def update_prediction(self, val):
        settings.set_setting('head_prediction', float(val))
    
    def update_delay(self, val):
        settings.set_setting('trigger_delay', float(val) / 1000)
    
    def update_esp_text(self):
        settings.set_setting('esp_text_enabled', self.text_var.get())
    
    def run(self):
        try:
            if settings.get_setting('menu_visible'):
                self.root.deiconify()
                self.root.update()
            else:
                self.root.withdraw()
                self.root.update_idletasks()
        except tk.TclError:
            pass

def instant_snap_move(target_x, target_y, screen_center_x, screen_center_y, smoothing):
    """Instant snap to target head with minimal smoothing"""
    diff_x = target_x - screen_center_x
    diff_y = target_y - screen_center_y
    
    # INSTANT LOCK
    if smoothing < 0.2:
        win32api.mouse_event(win32con.MOUSEEVENTF_MOVE, int(diff_x), int(diff_y), 0, 0)
    else:
        win32api.mouse_event(win32con.MOUSEEVENTF_MOVE, 
                            int(diff_x / smoothing), 
                            int(diff_y / smoothing), 0, 0)

def detect_head_region(box, frame_height):
    """Extract head region from bounding box (top 40% of box)"""
    x1, y1, x2, y2 = box
    height = y2 - y1
    head_height = height * 0.4
    return x1, y1, x2, y1 + head_height

def draw_rainbow_color(frame_count):
    """Cycle through rainbow colors"""
    hue = (frame_count * 2) % 360
    rgb_val = int((hue % 60) * 4.25)
    
    if hue < 60:
        return (255, rgb_val, 0)
    elif hue < 120:
        return (255 - rgb_val, 255, 0)
    elif hue < 180:
        return (0, 255, rgb_val)
    elif hue < 240:
        return (0, 255 - rgb_val, 255)
    elif hue < 300:
        return (rgb_val, 0, 255)
    else:
        return (255, 0, 255 - rgb_val)

def main():
    menu_obj = AdvancedMenu()
    menu_thread = Thread(target=lambda: [menu_obj.run() for _ in iter(int, 1)], daemon=True)
    menu_thread.start()

    pygame.init()

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"[*] Using device: {device}")

    try:
        model = YOLO(MODEL_NAME)
        model.to(device)
        if device == 'cuda':
            model.half()
        print(f"[+] Model loaded on {device}")
    except Exception as e:
        print(f"[-] Model load failed: {e}")
        return

    with mss() as sct:
        monitor = sct.monitors[1]
        screen_w, screen_h = monitor["width"], monitor["height"]
        screen_center_x, screen_center_y = screen_w // 2, screen_h // 2

        TRANSPARENT_COLOR = (1, 1, 1)
        COLOR_KEY = win32api.RGB(1, 1, 1)

        screen = pygame.display.set_mode((screen_w, screen_h), pygame.NOFRAME | pygame.SRCALPHA | pygame.DOUBLEBUF)
        hwnd = pygame.display.get_wm_info()['window']

        styles = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, 
                               styles | win32con.WS_EX_LAYERED | win32con.WS_EX_TRANSPARENT | win32con.WS_EX_TOPMOST)

        win32gui.SetLayeredWindowAttributes(hwnd, COLOR_KEY, 0, win32con.LWA_COLORKEY)
        win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, screen_w, screen_h, 
                              win32con.SWP_NOACTIVATE | win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)

        clock = pygame.time.Clock()
        insert_key_pressed = False
        delete_key_pressed = False
        running = True
        frame_count = 0

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            if win32api.GetAsyncKeyState(win32con.VK_INSERT) & 0x8000:
                if not insert_key_pressed:
                    current_visible = settings.get_setting('menu_visible')
                    settings.set_setting('menu_visible', not current_visible)
                    insert_key_pressed = True
            else:
                insert_key_pressed = False

            if win32api.GetAsyncKeyState(win32con.VK_DELETE) & 0x8000:
                if not delete_key_pressed:
                    running = False
                    delete_key_pressed = True
            else:
                delete_key_pressed = False

            screen.fill(TRANSPARENT_COLOR)

            # Draw Crosshair
            if settings.get_setting('crosshair_enabled'):
                pygame.draw.circle(screen, (255, 0, 0), (screen_center_x, screen_center_y), 3, 2)
                pygame.draw.line(screen, (255, 0, 0), (screen_center_x - 10, screen_center_y), 
                               (screen_center_x + 10, screen_center_y), 1)
                pygame.draw.line(screen, (255, 0, 0), (screen_center_x, screen_center_y - 10), 
                               (screen_center_x, screen_center_y + 10), 1)

            # Draw FOV
            if settings.get_setting('fov_enabled'):
                fov_radius = settings.get_setting('fov_radius')
                pygame.draw.circle(screen, (255, 0, 255), (screen_center_x, screen_center_y), fov_radius, 2)

            # Detection
            fov_radius = settings.get_setting('fov_radius')
            crop_size = min(fov_radius * 2 + 100, min(screen_w, screen_h))
            roi = {
                "top": max(0, screen_center_y - (crop_size // 2)),
                "left": max(0, screen_center_x - (crop_size // 2)),
                "width": min(crop_size, screen_w),
                "height": min(crop_size, screen_h)
            }

            try:
                screen_shot = sct.grab(roi)
                frame_bgr = cv2.cvtColor(np.array(screen_shot), cv2.COLOR_BGRA2BGR)
                results = model.predict(frame_bgr, classes=[0], conf=0.15, imgsz=320, verbose=False)
            except:
                results = []

            closest_head = None
            min_distance = float('inf')

            for result in results:
                boxes = result.boxes.xyxy.cpu().numpy()
                for box in boxes:
                    rx1, ry1, rx2, ry2 = map(int, box[:4])
                    x1 = rx1 + roi["left"]
                    y1 = ry1 + roi["top"]
                    box_w = rx2 - rx1
                    box_h = ry2 - ry1

                    # Draw body box
                    if settings.get_setting('esp_enabled'):
                        color = draw_rainbow_color(frame_count) if settings.get_setting('rainbow_mode') else (0, 255, 0)
                        pygame.draw.rect(screen, color, (x1, y1, box_w, box_h), 2)

                    # HEAD ONLY MODE - Extract head
                    if settings.get_setting('head_only_mode'):
                        head_x1, head_y1, head_x2, head_y2 = detect_head_region((x1, y1, x1 + box_w, y1 + box_h), screen_h)
                        head_w = head_x2 - head_x1
                        head_h = head_y2 - head_y1
                        
                        if settings.get_setting('esp_enabled'):
                            pygame.draw.rect(screen, (0, 255, 255), (int(head_x1), int(head_y1), int(head_w), int(head_h)), 3)
                        
                        head_center_x = head_x1 + head_w / 2
                        head_center_y = head_y1 + head_h / 2
                    else:
                        head_center_x = x1 + box_w / 2
                        head_center_y = y1 + box_h / 2

                    distance = math.sqrt((head_center_x - screen_center_x)**2 + (head_center_y - screen_center_y)**2)

                    if distance <= fov_radius and distance < min_distance:
                        min_distance = distance
                        closest_head = (head_center_x, head_center_y, distance)

            # INSTANT LOCK AIMBOT
            if settings.get_setting('aimbot_enabled') and (win32api.GetAsyncKeyState(0x02) & 0x8000):
                if closest_head is not None:
                    target_x, target_y, dist = closest_head
                    smoothing = settings.get_setting('aim_smoothing')
                    instant_snap_move(target_x, target_y, screen_center_x, screen_center_y, smoothing)

            pygame.display.flip()
            clock.tick(TARGET_FPS)
            frame_count += 1

    pygame.quit()

if __name__ == "__main__":
    main()
